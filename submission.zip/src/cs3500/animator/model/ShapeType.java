package cs3500.animator.model;

/**
 * Represents what Shapes are supported by this program. We can add as many as are needed.
 */
public enum ShapeType {
  RECTANGLE, ELLIPSE
}
