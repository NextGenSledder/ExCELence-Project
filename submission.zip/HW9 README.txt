We only worked on Level 1 for this assignment
The files affected are:

ButtonPanel (src-->cs3500-->animator-->view)
ScrubbingTests (test-->cs3500-->animator-->view)
